# Ubicacion GPS - Laboratorio Dispositivos Convergentes

App Android (Java) que obtiene la ubicacion GPS con `FusedLocationProviderClient` y `Geocoder`,
y permite que los estudiantes de un curso reporten donde viven para identificar las zonas con mas estudiantes.

## Funcionalidad
- Boton **Ubicacion**: muestra latitud, longitud, pais, ciudad y direccion.
- **Reportar mi ubicacion**: guarda nombre + zona (barrio o ciudad) en SQLite local. Cada estudiante cuenta una sola vez.
- **Ver zonas con mas estudiantes**: lista de zonas ordenada de mayor a menor.

## Como abrirlo
1. Android Studio -> File -> Open -> carpeta `UbicacionGPS`.
2. Esperar el Gradle Sync.
3. Ejecutar en un dispositivo/emulador con Google Play Services y GPS activo.

## Nota
`getLastLocation()` puede devolver null si el dispositivo nunca ha obtenido ubicacion; abre Google Maps una vez.
